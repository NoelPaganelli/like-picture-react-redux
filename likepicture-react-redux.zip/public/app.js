var React     = require('react');
var ReactDOM  = require('react-dom');
var createStore =  require('redux').createStore;
var Provider    =  require('react-redux').Provider;
var connect     = require('react-redux').connect;


class Picture extends React.Component {
 
   constructor() {
    super();
  
  }
  
  render() {

    return(
      <div className="row">
        <div className="col-xs-offset-4 col-xs-4">
          <img className="img-responsive" src="./flowers.jpg" />
          <MessageForm/>
          <MessageList/>
        </div>
      </div>
     )
  }
}

class MessageForm extends React.Component {
  
  constructor() {
    super();
  
  }
  
 
  render() {

    return(
  
      <div className="form-signin">
        <form>
          <label className="sr-only">Message</label>
          <input type="text" id="message" className="form-control" placeholder="votre message" />
          <input id="valider" className="btn btn-warning  btn-lg btn-block" value="Valider" type="submit" />
        </form>
      </div>
        
     )
  }
}  


class MessageList extends React.Component {
  
  constructor() {
    super();
  
  }
  
 
  render() {

    return(
      <div>
        <h2 className="form-signin-heading">5 like(s) <a href="#"><span className="glyphicon glyphicon-thumbs-up"></span></a></h2>
        <ul className="list-group">
         <li className="list-group-item">Top la photo !</li>
         <li className="list-group-item">Vive les vacances</li>
        </ul>
      </div>
     )
  }
}  

ReactDOM.render(  
    <div>
      <Picture/>
    </div>
  ,
  document.getElementById('container')
);